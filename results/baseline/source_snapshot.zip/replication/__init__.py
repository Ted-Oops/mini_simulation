"""Chiarella–Iori–Perelló 原文复现；与扩展项目的规则及 LLM 完全分离。"""
