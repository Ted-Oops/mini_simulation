"""有限样本诊断；不把厚尾估计或相关性当作因果证据。"""

import math
import numpy as np


METRIC_LABELS = {
    "return_volatility": "对数收益波动率", "excess_kurtosis": "收益超额峰度",
    "hill_absolute": "绝对收益希尔尾指数", "abs_return_acf1": "绝对收益一阶自相关",
    "abs_return_acf10": "绝对收益十阶自相关", "fundamental_error": "基本价值相对偏离均值",
    "mean_spread_ticks": "平均买卖价差（最小价位）", "two_sided_ratio": "双边盘口存在比例",
    "mean_depth": "平均盘口总深度（股）", "trade_volume_per_step": "每事件成交量（股）",
    "zero_return_ratio": "零收益比例", "gap_return_correlation": "成交前缺口与绝对收益相关",
    "volume_return_correlation": "来单量与绝对收益相关", "marketable_ratio": "可立即成交限价单比例",
    "placement_distance": "平均挂单距离（最小价位）", "lo_rs_beta": "修正极差尺度诊断指数",
    "hill_gap": "首档缺口希尔尾指数", "hill_placement": "挂单距离希尔尾指数",
}


def finite_mean(values):
    values = [value for value in values if value is not None and math.isfinite(value)]
    return float(np.mean(values)) if values else None


def correlation(x, y):
    if len(x) < 20 or np.std(x) < 1e-14 or np.std(y) < 1e-14:
        return None
    return float(np.corrcoef(x, y)[0, 1])


def autocorrelation(values, lag):
    data = np.asarray(values, dtype=float)
    if len(data) <= lag or np.var(data) < 1e-28:
        return None
    centered = data - np.mean(data)
    return float(np.dot(centered[lag:], centered[:-lag]) / np.dot(centered, centered))


def hill_index(values, fraction=0.05, minimum_tail=20):
    data = np.sort(np.asarray([x for x in values if x > 0 and math.isfinite(x)]))[::-1]
    count = int(len(data) * fraction)
    if count < minimum_tail or count >= len(data):
        return None
    gamma = float(np.mean(np.log(data[:count] / data[count])))
    return 1 / gamma if gamma > 1e-12 else None


def modified_rs(values, q=20):
    data = np.asarray(values, dtype=float)
    if len(data) < max(64, q + 2):
        return None
    centered = data - data.mean()
    variance = float(np.dot(centered, centered) / len(data))
    for lag in range(1, q + 1):
        gamma = float(np.dot(centered[lag:], centered[:-lag]) / len(data))
        variance += 2 * (1 - lag / (q + 1)) * gamma
    if variance <= 1e-28:
        return None
    cumulative = np.concatenate(([0.0], np.cumsum(centered)))
    statistic = float(np.ptp(cumulative) / math.sqrt(variance))
    return math.log(statistic) / math.log(len(data)) if statistic > 0 else None


def evaluate_summary(summary, burn_in=0):
    prices = np.asarray(summary["price_history"], dtype=float)
    returns = np.diff(np.log(prices))[burn_in:]
    if len(returns) < 2:
        raise ValueError("剔除初始过渡期后至少需要两个收益观测")
    absolute = np.abs(returns)
    variance = float(np.var(returns))
    excess = float(np.mean((returns - returns.mean()) ** 4) / variance ** 2 - 3) if variance > 1e-28 else None
    fundamental = np.asarray(summary["fundamental_history"], dtype=float)[burn_in + 1:]
    snapshots = [s for s in summary["microstructure_history"] if s["step"] > burn_in]
    flows = [s for s in summary["order_flow_history"] if s["step"] > burn_in]
    paired = [s for s in snapshots if s["opposite_gap_ticks"] is not None]
    return {
        "observations": len(returns),
        "return_volatility": math.sqrt(variance), "excess_kurtosis": excess,
        "hill_absolute": hill_index(absolute),
        "hill_positive": hill_index(returns), "hill_negative": hill_index(-returns),
        "abs_return_acf1": autocorrelation(absolute, 1),
        "abs_return_acf10": autocorrelation(absolute, 10),
        "lo_rs_beta": modified_rs(absolute),
        "fundamental_error": float(np.mean(np.abs(prices[burn_in + 1:] / fundamental - 1))),
        "zero_return_ratio": float(np.mean(absolute < 1e-14)),
        "mean_spread_ticks": finite_mean([s["spread_ticks"] for s in snapshots]),
        "two_sided_ratio": finite_mean([int(s["two_sided"]) for s in snapshots]),
        "mean_depth": finite_mean([s["bid_depth"] + s["ask_depth"] for s in snapshots]),
        "trade_volume_per_step": float(np.mean(summary["volume_history"][burn_in:])),
        "marketable_ratio": finite_mean([int(f["marketable"]) for f in flows]),
        "placement_distance": finite_mean([f["placement_distance_ticks"] for f in flows]),
        "gap_return_correlation": correlation([s["opposite_gap_ticks"] for s in paired], [abs(s["return"]) for s in paired]),
        "gap_pair_count": len(paired),
        "hill_gap": hill_index([s[key] for s in snapshots for key in ("bid_gap_ticks", "ask_gap_ticks") if s[key] is not None]),
        "hill_placement": hill_index([f["placement_distance_ticks"] for f in flows]),
        "volume_return_correlation": correlation([s["submitted_volume"] for s in snapshots], [abs(s["return"]) for s in snapshots]),
        "return_acf": [autocorrelation(returns, lag) for lag in range(1, 51)],
        "absolute_return_acf": [autocorrelation(absolute, lag) for lag in range(1, 51)],
    }


def paired_bootstrap(differences, seed=123, repeats=3000):
    data = np.asarray([d for d in differences if d is not None and math.isfinite(d)])
    if len(data) < 3:
        return {"n": len(data), "mean": float(data.mean()) if len(data) else None, "ci_low": None, "ci_high": None}
    generator = np.random.default_rng(seed)
    means = generator.choice(data, size=(repeats, len(data)), replace=True).mean(axis=1)
    return {"n": len(data), "mean": float(data.mean()),
            "ci_low": float(np.quantile(means, 0.025)), "ci_high": float(np.quantile(means, 0.975))}
